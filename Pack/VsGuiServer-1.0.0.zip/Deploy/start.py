﻿import subprocess
subprocess.call(['.\\VsGuiCore.Server.exe'])